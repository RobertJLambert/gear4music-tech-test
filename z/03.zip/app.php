<?php 
// #day dispatch period start
// # new batch
// # parcels = consignment . id number <= couriers
// #night dispatch period end
// # id numbers =>$method courier





/**
 * Orders class
 */

// class Orders
// {

//     public function __construct(Type $var = null)
//     {
//         /** @var Type $var description */
//         $var = null;
    
//     }
    
// }


interface Batch 
{
    public function startDispatch();
}



class Consignments implements Batch
{
    public $IDNumber; 
    public $now ;

    public function __construct($IDNumber) {
        $this->IDNumber = $IDNumber;
    }
    
    public function add($productID = null)
    {
    }
    
    public function startDispatch()
    {
        $this->$now = date("Y-m-d H:i:s");
    }
}


class Parcels extends Consignments 
{
    // parent::__construct($IDNumber);
}


class cityHall
{
    private static $instance = null;
    private function __construct()
    {
        
    }
    public static function getInstance()
    {
        if (self::$instance == null){
            self::$instance = new Singleton();
        }
        return self::$instance;
    }
}

echo "hi "  . date("Y-m-d H:i:s");



class Programmer {
	public $name;
	public function __construct(string $name) {
		$this -> name = $name;
	}
	public function greet() {
		return "Hello World from " . $this -> name;
	}
}
$programmer = new Programmer('John');
echo $programmer -> greet();


