<?php

/**
 * undocumented class
 */
class Orders
{


    public function __construct(Type $var = null)
    {
        /** @var Type $var description */
        protected $var = null;
        
        

    }
    
}

interface Batch {
    
}


class Consignment  
{
    public var $IDNumber; 

    public function __construct($IDNumber) {
        $this->IDNumber = $IDNumber;
    }
    
    public function Add(Type $var = null)
    {
        # code...
    }
}

class Batch extends AnotherClass implements Batch
{
    
}




?>
