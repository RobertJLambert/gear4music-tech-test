<?php

interface Batch 
{
    public function startDispatch();
}

