<?php
namespace Batch;

interface BatchI
{
    public function startDispatch();
    public function add();
}

class Batch implements BatchI
{

    public function __construct() {
        // $this->now = $now;
    }
    
    public function startDispatch()
    {
       $now = date("Y-m-d H:i:s");
       return "hi BatchStart $now";

    }
    
    public function add($productID = null)
    {
    }
}

