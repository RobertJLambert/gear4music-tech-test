<?php
namespace Batch;

class Consignments extends Batch
{
    public $parcelsIDs; 

    public function __construct() {
    }

    public function Parcels() {
        return "hi Consignments";
    }
}