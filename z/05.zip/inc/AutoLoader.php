<?php

spl_autoload_register("AutoLoader");

function AutoLoader (string $classFolder, string $className) 
{
     $file = "classes/" . $classFolder . "/" . $className . ".php";

    if ( file_exists( $file )){
        require_once( $file );
    }
}