<?php

/**
 * Parcels class
 */
class Parcels extends Consignments 
{
    // parent::__construct($IDNumber);
}