<?php

class Consignments implements Batch
{
    public $IDNumber; 
    public $now;

    public function __construct($IDNumber, $now) {
        $this->IDNumber = $IDNumber;
        $this->now = $now;
    }
    
    public function add($productID = null)
    {
    }
    
    public function startDispatch()
    {
        $now = date("Y-m-d H:i:s");
    }
}