<?php
namespace BatchStart;

class BatchStart 
{
    public $idNumber; 
    public $now;
    // $idNumber, $now
    public function __construct() {
        // $this->idNumber = $idNumber;
        // $this->now = $now;
        // return "hi BatchStart "  . date("Y-m-d H:i:s");
    }
    
    public function add($productID = null)
    {
        return "hi BatchStart "  . date("Y-m-d H:i:s");

    }
    
    public function startDispatch()
    {
        // $now = date("Y-m-d H:i:s");
    }
}

