<?php

/**
 * Orders class
 */

class Orders
{
    public function __construct(string $var = null)
    {
        /** @var Type $var description */
        $var = null;

    }

}