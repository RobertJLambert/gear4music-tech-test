<?php 
// #day dispatch period start
// # new batch
// # parcels = consignment . id number <= couriers
// #night dispatch period end
// # id numbers =>$method courier

spl_autoload_register("AutoLoader");
function AutoLoader ($classFolder, $className) 
{
     $file = "classes/" . $classFolder . "/" . $className . ".php";

    if ( file_exists( $file )){
        require_once( $file );
    }
}

AutoLoader("BatchStart", "BatchStart");
$batch = new BatchStart\BatchStart();
echo $batch->add();


// class cityHall
// {
//     private static $instance = null;
//     private function __construct()
//     {
        
//     }
//     public static function getInstance()
//     {
//         if (self::$instance == null){
//             self::$instance = new Singleton();
//         }
//         return self::$instance;
//     }
// }

// echo "hi "  . date("Y-m-d H:i:s");



// class Programmer {
// 	public $name;
// 	public function __construct( $name) {
// 		$this -> name = $name;
// 	}
// 	public function greet() {
// 		return "Hello World from " . $this -> name;
// 	}
// }
// $programmer = new Programmer('John');
// echo $programmer -> greet();


